class RelayedTransactionV1Builder:
    def __init__(self) -> None:
        raise NotImplementedError()


class RelayedTransactionV2Builder:
    def __init__(self) -> None:
        raise NotImplementedError()
