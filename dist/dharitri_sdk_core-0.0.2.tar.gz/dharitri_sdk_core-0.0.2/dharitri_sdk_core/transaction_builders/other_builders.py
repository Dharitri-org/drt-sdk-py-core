class SaveKeyValuesBuilder:
    def __init__(self) -> None:
        raise NotImplementedError()


class SetUsernameBuilder:
    def __init__(self) -> None:
        raise NotImplementedError()


class ChangeOwnerAddressBuilder:
    def __init__(self) -> None:
        raise NotImplementedError()


class ClaimDeveloperRewardsBuilder:
    def __init__(self) -> None:
        raise NotImplementedError()
